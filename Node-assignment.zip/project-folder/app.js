// project-folder/app.js
const express = require('express');
const { json } = require('body-parser');
const itemsRoutes = require('./routes/itemsRoutes.js'); 

const app = express();
const port = process.env.PORT || 3000;

app.use(json());

// Mount the items route
app.use('/items', itemsRoutes);

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
