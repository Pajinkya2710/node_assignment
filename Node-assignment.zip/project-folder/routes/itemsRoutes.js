// routes/itemsRoutes.js
const express = require('express');
const router = express.Router();
const {
  getAllItems,
  createItem,
  getItemById,
  updateItem,
  deleteItem,
} = require('../controllers/items');

// GET all items
router.get('/', getAllItems);

// POST create a new item
router.post('/', createItem);

// GET an item by ID
router.get('/:id', getItemById);

// PUT update an item by ID
router.put('/:id', updateItem);

// DELETE an item by ID
router.delete('/:id', deleteItem);

module.exports = router;
