// controllers/items.js
const fs = require('fs');
const path = require('path');
const { validationResult } = require('express-validator');

const dataFilePath = path.join(__dirname, '../data/items.json');

// Controller function to get all items with pagination, filtering, and sorting
const getAllItems = (req, res) => {
  try {
    // Read the JSON file containing items
    const rawData = fs.readFileSync(dataFilePath, 'utf-8');
    const items = JSON.parse(rawData);

    // Pagination
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const paginatedItems = items.slice(startIndex, endIndex);

    // Filtering
    const { name, category } = req.query;
    const filteredItems = paginatedItems.filter((item) => {
      if (name && category) {
        return item.name.includes(name) && item.category === category;
      } else if (name) {
        return item.name.includes(name);
      } else if (category) {
        return item.category === category;
      } else {
        return true; // No filters applied
      }
    });

    // Sorting
    const { sort } = req.query;
    if (sort === 'asc') {
      filteredItems.sort((a, b) => (a.name > b.name ? 1 : -1));
    } else if (sort === 'desc') {
      filteredItems.sort((a, b) => (a.name < b.name ? 1 : -1));
    }

    res.status(200).json({
      success: true,
      data: filteredItems,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({
      success: false,
      message: 'Internal Server Error',
    });
  }
};
// Controller function to create a new item
const createItem = (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const newItem = {
      id: Date.now(), // You can generate a unique ID here
      name: req.body.name,
      category: req.body.category,
      // Add other item properties as needed
    };

    // Read existing items from the JSON file
    const rawData = fs.readFileSync(dataFilePath, 'utf-8');
    const items = JSON.parse(rawData);

    // Add the new item to the array
    items.push(newItem);

    // Write the updated items back to the JSON file
    fs.writeFileSync(dataFilePath, JSON.stringify(items, null, 2), 'utf-8');

    res.status(201).json({
      success: true,
      data: newItem,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({
      success: false,
      message: 'Internal Server Error',
    });
  }
};

// Controller function to get an item by its ID
const getItemById = (req, res) => {
  try {
    const itemId = parseInt(req.params.id); // Convert the ID to an integer
    
    // Read the JSON file containing items
    const rawData = fs.readFileSync(dataFilePath, 'utf-8');
    const items = JSON.parse(rawData);

    // Find the item with the matching ID
    const foundItem = items.find(item => item.id === itemId);

    if (!foundItem) {
      return res.status(404).json({
        success: false,
        message: 'Item not found',
      });
    }

    res.status(200).json({
      success: true,
      data: foundItem,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({
      success: false,
      message: 'Internal Server Error',
    });
  }
};

// Controller function to update an item by its ID
const updateItem = (req, res) => {
  try {
    const itemId = parseInt(req.params.id); // Convert the ID to an integer
    
    // Read the JSON file containing items
    const rawData = fs.readFileSync(dataFilePath, 'utf-8');
    const items = JSON.parse(rawData);

    // Find the index of the item with the matching ID
    const itemIndex = items.findIndex(item => item.id === itemId);

    if (itemIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Item not found',
      });
    }

    // Update the item with the new data
    items[itemIndex] = {
      ...items[itemIndex],
      ...req.body,
    };

    // Write the updated items back to the JSON file
    fs.writeFileSync(dataFilePath, JSON.stringify(items, null, 2), 'utf-8');

    res.status(200).json({
      success: true,
      data: items[itemIndex],
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({
      success: false,
      message: 'Internal Server Error',
    });
  }
};

// Controller function to delete an item by its ID
const deleteItem = (req, res) => {
  try {
    const itemId = parseInt(req.params.id); // Convert the ID to an integer
    
    // Read the JSON file containing items
    const rawData = fs.readFileSync(dataFilePath, 'utf-8');
    const items = JSON.parse(rawData);

    // Find the index of the item with the matching ID
    const itemIndex = items.findIndex(item => item.id === itemId);

    if (itemIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Item not found',
      });
    }

    // Remove the item from the array
    items.splice(itemIndex, 1);

    // Write the updated items back to the JSON file
    fs.writeFileSync(dataFilePath, JSON.stringify(items, null, 2), 'utf-8');

    res.status(204).json(); // 204 No Content response
  } catch (err) {
    console.error(err);
    res.status(500).json({
      success: false,
      message: 'Internal Server Error',
    });
  }
};

module.exports = {
  getAllItems,
  createItem,
  getItemById,
  updateItem,
  deleteItem,
};
